import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Knowledge Explorer",
  description: "Build, expand and remember your general knowledge."
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}
