import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const { topic, notes } = await req.json();
    if (!topic || typeof topic !== "string" || topic.length > 180) {
      return NextResponse.json({ error: "Enter a topic (maximum 180 characters)." }, { status: 400 });
    }
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return NextResponse.json({ error: "AI is not configured yet. Add OPENAI_API_KEY to your hosting environment." }, { status: 503 });

    const prompt = `You are Knowledge Explorer, a careful general-knowledge tutor. Expand the user's topic into accurate, useful, memorable facts.
Topic: ${topic}
Existing notes: ${String(notes || "").slice(0, 5000)}

Return Markdown with these headings:
## Overview
## History
## Geography and nature
## Politics and society
## Culture
## Economy and notable facts
## Connections to explore
Include only relevant sections; do not invent facts or force categories. Correct misconceptions gently. Distinguish well-established facts from disputed or uncertain claims. Give dates and names where useful. For a place, include native wildlife only when reliably known. Avoid trivia-padding. End with 5 concise recall questions, but do not provide their answers in that section. Cite reputable source names and provide links when you can do so reliably; never fabricate citations.`;
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          { role: "system", content: "Be factually careful. If a detail is uncertain, say so. Do not make up citations or historical events." },
          { role: "user", content: prompt }
        ],
        temperature: 0.4
      })
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: data?.error?.message || "The AI provider returned an error." }, { status: response.status });
    return NextResponse.json({ content: data.choices?.[0]?.message?.content || "No content returned." });
  } catch {
    return NextResponse.json({ error: "Something went wrong while expanding this topic." }, { status: 500 });
  }
}
