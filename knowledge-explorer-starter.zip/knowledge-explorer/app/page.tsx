"use client";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Topic = { id: string; title: string; notes: string; expansion: string; category: string; created_at: string };
type Tab = "explore" | "recall" | "library";
const KEY = "knowledge-explorer-topics-v1";

export default function Home() {
  const [tab, setTab] = useState<Tab>("explore");
  const [topic, setTopic] = useState("");
  const [notes, setNotes] = useState("");
  const [category, setCategory] = useState("General knowledge");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState("");
  const [items, setItems] = useState<Topic[]>([]);
  const [selected, setSelected] = useState<Topic | null>(null);
  const [recallTopic, setRecallTopic] = useState<Topic | null>(null);
  const [recallAnswers, setRecallAnswers] = useState<string[]>([]);
  const [recallStarted, setRecallStarted] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authMessage, setAuthMessage] = useState("");

  useEffect(() => {
    const local = localStorage.getItem(KEY);
    if (local) setItems(JSON.parse(local));
    if (supabase) {
      supabase.auth.getUser().then(({ data }) => setUserEmail(data.user?.email || ""));
      const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUserEmail(session?.user?.email || ""));
      return () => listener.subscription.unsubscribe();
    }
  }, []);

  useEffect(() => {
    if (!supabase || !userEmail) return;
    supabase.from("topics").select("*").order("created_at", { ascending: false }).then(({ data }) => {
      if (data) setItems(data as Topic[]);
    });
  }, [userEmail]);

  function persist(next: Topic[]) {
    setItems(next);
    if (!supabase || !userEmail) localStorage.setItem(KEY, JSON.stringify(next));
  }
  async function saveTopic(t: Topic) {
    const next = [t, ...items.filter(x => x.id !== t.id)];
    setItems(next);
    if (supabase && userEmail) {
      const { error } = await supabase.from("topics").upsert({
        id: t.id, title: t.title, notes: t.notes, expansion: t.expansion,
        category: t.category, created_at: t.created_at
      });
      if (error) setError("Cloud save failed: " + error.message);
    } else localStorage.setItem(KEY, JSON.stringify(next));
  }
  async function expand() {
    setError(""); setResult("");
    if (!topic.trim()) return setError("Enter a topic first.");
    setBusy(true);
    try {
      const r = await fetch("/api/expand", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ topic: topic.trim(), notes }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Unable to expand topic.");
      setResult(data.content);
    } catch (e) { setError(e instanceof Error ? e.message : "Request failed."); }
    finally { setBusy(false); }
  }
  async function saveCurrent() {
    const t: Topic = { id: crypto.randomUUID(), title: topic.trim(), notes, expansion: result, category, created_at: new Date().toISOString() };
    await saveTopic(t); setSelected(t); setTab("library");
  }
  async function signIn() {
    if (!supabase) return setAuthMessage("Add Supabase environment variables to enable cloud sync.");
    const { error } = await supabase.auth.signInWithOtp({ email: authEmail, options: { emailRedirectTo: window.location.origin } });
    setAuthMessage(error ? error.message : "Check your email for your sign-in link.");
  }
  async function signOut() { await supabase?.auth.signOut(); setUserEmail(""); }
  function deleteTopic(id: string) {
    const next = items.filter(x => x.id !== id); persist(next);
    if (supabase && userEmail) supabase.from("topics").delete().eq("id", id);
    if (selected?.id === id) setSelected(null);
  }
  const categories = ["General knowledge","History","Geography","Science","Nature & wildlife","Politics","Culture & art","Literature","Sports","Technology"];
  const current = selected;
  const recallQuestions = useMemo(() => {
    if (!recallTopic) return [];
    return recallTopic.expansion.split("\n").filter(line => /^\s*(\d+[\.\)]|[-*])\s+/.test(line)).slice(-5);
  }, [recallTopic]);

  return <main className="shell">
    <header className="topbar">
      <a className="brand" href="#"><span className="brandIcon">K</span><span>Knowledge Explorer<small>YOUR PERSONAL KNOWLEDGE BASE</small></span></a>
      <div className="account">{supabase ? (userEmail ? <><span>{userEmail}</span><button className="quiet" onClick={signOut}>Sign out</button></> : <span>Cloud sync available</span>) : <span>Private local library</span>}</div>
    </header>
    <section className="hero">
      <div><div className="eyebrow">LEARN SOMETHING EVERY DAY</div><h1>Turn curiosity into<br/><em>lasting knowledge.</em></h1><p>Expand the facts you discover, keep everything organized, and test your memory when you're ready.</p></div>
      <div className="heroMark">✳</div>
    </section>
    <nav className="tabs">
      <button className={tab==="explore"?"active":""} onClick={()=>setTab("explore")}>✦ Explore</button>
      <button className={tab==="recall"?"active":""} onClick={()=>setTab("recall")}>◉ Recall</button>
      <button className={tab==="library"?"active":""} onClick={()=>setTab("library")}>▤ My Library <span className="count">{items.length}</span></button>
    </nav>

    {tab==="explore" && <section className="panel">
      <div className="sectionHead"><div><div className="eyebrow">01 / DISCOVER</div><h2>Explore a topic</h2><p>Start with a trivia answer, a place, a person, or a subject you want to understand.</p></div><span className="stepIcon">✦</span></div>
      <label>TOPIC<input value={topic} onChange={e=>setTopic(e.target.value)} placeholder="e.g. San Marino, Rosetta Stone, Marie Curie"/></label>
      <div className="twoCol">
        <label>CATEGORY<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select></label>
        <label>YOUR EXISTING NOTES <span className="optional">OPTIONAL</span><textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Paste what you already know or your original Krillion note..." rows={3}/></label>
      </div>
      <button className="primary" disabled={busy || !topic.trim()} onClick={expand}>{busy?"Researching...":"Expand my knowledge →"}</button>
      {error && <div className="error">{error}</div>}
      {result && <div className="result">
        <div className="resultHead"><div><div className="eyebrow">YOUR KNOWLEDGE EXPANSION</div><h3>{topic}</h3></div><button className="primary small" onClick={saveCurrent}>＋ Save to library</button></div>
        <article className="markdown">{result.split("\n").map((line,i)=>line.startsWith("## ")?<h3 key={i}>{line.slice(3)}</h3>:line.startsWith("- ")||line.startsWith("* ")?<p key={i}>• {line.slice(2)}</p>:line.trim()?<p key={i}>{line}</p>:<br key={i}/>)}</article>
      </div>}
    </section>}

    {tab==="recall" && <section className="panel">
      <div className="sectionHead"><div><div className="eyebrow">02 / REMEMBER</div><h2>Recall practice</h2><p>A separate study space. Nothing here changes your Explore workflow.</p></div><span className="stepIcon">◉</span></div>
      {!recallTopic ? <><p className="muted">Choose a saved topic to study. For a proper test, read the topic title only and try to reconstruct the details from memory.</p><div className="topicGrid">{items.map(t=><button className="topicCard" key={t.id} onClick={()=>{setRecallTopic(t);setRecallStarted(false);setRecallAnswers([])}}><span>{t.category}</span><strong>{t.title}</strong><small>Saved {new Date(t.created_at).toLocaleDateString()}</small></button>)}</div>{items.length===0&&<div className="empty">Your library is empty. Explore and save a topic first.</div>}</>
      : <div className="recallBox"><button className="back" onClick={()=>{setRecallTopic(null);setRecallStarted(false)}}>← All topics</button><div className="eyebrow">RECALL SESSION</div><h2>{recallTopic.title}</h2><p>Without opening your notes, write down everything you can remember about this topic.</p><textarea rows={8} value={recallAnswers[0]||""} onChange={e=>setRecallAnswers([e.target.value])} placeholder="Write everything you remember..."/>{!recallStarted?<button className="primary" onClick={()=>setRecallStarted(true)}>Reveal my saved notes →</button>:<><div className="answerReveal"><h3>Compare with your saved knowledge</h3><article className="markdown">{recallTopic.expansion.split("\n").map((line,i)=>line.startsWith("## ")?<h3 key={i}>{line.slice(3)}</h3>:line.trim()?<p key={i}>{line}</p>:<br key={i}/>)}</article></div><button className="quiet" onClick={()=>{setRecallTopic(null);setRecallStarted(false);setRecallAnswers([])}}>Finish session</button></>}</div>}
    </section>}

    {tab==="library" && <section className="panel">
      <div className="sectionHead"><div><div className="eyebrow">03 / YOUR COLLECTION</div><h2>My Library</h2><p>Your saved topics and expanded knowledge.</p></div><span className="stepIcon">▤</span></div>
      {supabase && !userEmail && <div className="signin"><h3>Enable cloud sync</h3><p>Sign in with an email link to sync your library across devices.</p><div className="inlineForm"><input type="email" value={authEmail} onChange={e=>setAuthEmail(e.target.value)} placeholder="you@example.com"/><button className="primary small" onClick={signIn}>Send sign-in link</button></div>{authMessage&&<small>{authMessage}</small>}</div>}
      {items.length===0?<div className="empty">No saved topics yet. Start by exploring something interesting.</div>:<div className="libraryList">{items.map(t=><div className="libraryItem" key={t.id}><button className="libraryOpen" onClick={()=>setSelected(current?.id===t.id?null:t)}><span className="category">{t.category}</span><strong>{t.title}</strong><small>{new Date(t.created_at).toLocaleDateString()}</small></button><button className="delete" aria-label="Delete topic" onClick={()=>deleteTopic(t.id)}>×</button>{current?.id===t.id&&<div className="savedContent"><p><b>Your original notes</b><br/>{t.notes||"No original notes."}</p><article className="markdown">{t.expansion.split("\n").map((line,i)=>line.startsWith("## ")?<h3 key={i}>{line.slice(3)}</h3>:line.trim()?<p key={i}>{line}</p>:<br key={i}/>)}</article><button className="quiet" onClick={()=>{setRecallTopic(t);setTab("recall");setRecallStarted(false)}}>Practice recall →</button></div>}</div>)}</div>}
    </section>}
    <footer><span>KNOWLEDGE EXPLORER</span><span>Explore freely. Remember deliberately.</span></footer>
  </main>;
}
