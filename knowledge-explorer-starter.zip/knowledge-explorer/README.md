# Knowledge Explorer

A Next.js hosted web app for expanding trivia notes, keeping a personal knowledge library, and practicing recall in a separate mode.

## Features
- Explore: submit a topic and existing notes for an AI-generated knowledge expansion.
- Recall: separate free-recall practice using saved topics; reveal notes only after writing your answer.
- My Library: save, browse, and delete topics.
- Optional Supabase cloud sync using email magic-link authentication. Without Supabase credentials, the library stays in this browser's local storage.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env.local`.
3. Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL`.
4. Run `npm install`, then `npm run dev`.
5. Open http://localhost:3000.

## Deploy to Vercel
1. Push this folder to a GitHub repository.
2. Import the repository into Vercel.
3. Add `OPENAI_API_KEY` and `OPENAI_MODEL` as environment variables.
4. Deploy.

## Enable cross-device cloud sync (optional)
Create a Supabase project and set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel. Then run this SQL in Supabase SQL Editor:

```sql
create table public.topics (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  title text not null,
  notes text not null default '',
  expansion text not null default '',
  category text not null default 'General knowledge',
  created_at timestamptz not null default now()
);

alter table public.topics enable row level security;

create policy "Users can read their own topics"
on public.topics for select using (auth.uid() = user_id);

create policy "Users can insert their own topics"
on public.topics for insert with check (auth.uid() = user_id);

create policy "Users can update their own topics"
on public.topics for update using (auth.uid() = user_id);

create policy "Users can delete their own topics"
on public.topics for delete using (auth.uid() = user_id);
```

For cloud sync, the `topics` table needs a `user_id` default as shown above. The app's current upsert payload omits `user_id`, allowing the database default to assign it.

## Notes
- AI requests use the OpenAI API from a server-side route. The API key is never sent to the browser.
- API usage may incur provider charges and is subject to provider rate limits.
- The current MVP produces an educational overview and suggested recall prompts. The Recall tab currently uses free-recall writing and reveal, not automatically graded quiz questions.
- Add citations verification and a dedicated source retrieval/search provider before treating generated material as fully researched reference material.
